﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/* **********************************************
* 프로그램명 : Results_remark.cs
• 팀 : 5조 파인애플 피자(신은지, 이송이, 최은정, 최세화, 류서현, 홍예지)
• 작성자 : 2018038060 홍예지
• 작성일 : 2019.09.19
*프로그램 설명 : 성적 입력, 평균 계산 프로그램
************************************************/


namespace Results
{
    class Student//(attribute) kor,math,eng, (method) setScore(),getAverage() 가 있는 클래스
    {
        public int kor, math, eng;//입력받을 세 과목의 점수 변수

        public void setScore() {//각 성적 입력받는 함수
            Console.WriteLine("국어성적 : ");
            kor = int.Parse(Console.ReadLine());//국어성적을 입력받아 정수형태로 변환하여 변수에 저장한다
            Console.WriteLine("수학성적 : ");
            math = int.Parse(Console.ReadLine());//수학성적을 입력받아 정수형태로 변환하여 변수에 저장한다
            Console.WriteLine("영어성적 : ");
            eng = int.Parse(Console.ReadLine());//영어성적을 입력받아 정수형태로 변환하여 변수에 저장한다
        }
        public float getAverage() {//평균 계산 함수
            return (float)(kor + math + eng) / 3;//평균을 계산해 실수형으로 반환한다
        }
    }
    class Results_remark//메인메소드가 있는 클래스
    {
        static void Main(string[] args)
        {
            Student std = new Student();//Student클래스의 객체인 std를 생성한다
            std.setScore();//객체의 메소드를 이용해 성적 입력
            
            Console.WriteLine("과목의 평균은 : {0:f2}",std.getAverage());//객체의 메소드를 이용해 평균 계산, 결과값을 소수점 두자리까지 출력한다
            
        }
    }
}
