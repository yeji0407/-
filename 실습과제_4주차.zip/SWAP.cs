﻿/*
 * 프로그램명 : SWAP.cs
 * 작성자: 2018038060 홍예지
 * 작성일:2019.9.27
 * 프로그램 설명: call by reference를 이용해 두 변수 값 바꾸기
 * */



using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class SWAP
    {
        static void Main(string[] args)
        {
            int x = 10;int y = 20;

            SWAP app = new SWAP();
            Console.WriteLine("x={0},y={1}", x, y);
            app.swap(ref x, ref y);
            Console.WriteLine("x={0},y={1}", x, y);

        }
        public void swap(ref int a,ref int b)
        {
            int temp;
            temp = a;
            a = b;
            b = temp;
        }
    }
}
