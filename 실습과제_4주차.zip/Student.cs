﻿/*
 * 프로그램명 : Student.cs
 * 작성자: 2018038060 홍예지
 * 작성일:2019.9.27
 * 프로그램 설명: 세명의 학생의 세 과목 점수 받아 평균 내기
 * */




using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class Student
    {
        static void Main(string[] args)
        {
            Student[] sList = new Student[3];

            for(int i=0;i<3;i++)
            {
                sList[i] = new Student();
                Console.WriteLine("Student? : {0}", i + 1);
                Console.WriteLine("Korean? : ");
                sList[i].kor = int.Parse(Console.ReadLine());
                Console.WriteLine("Math? : ");
                sList[i].math = int.Parse(Console.ReadLine());
                Console.WriteLine("Eng? : ");
                sList[i].eng = int.Parse(Console.ReadLine());
            }
            for(int i=0;i<3;i++)
            {
                Console.WriteLine("Average = {0}", sList[i].ave);
            }
        }

        private int kor
        {
            get;set;
        }
        private int math
        {
            get; set;
        }
        private int eng
        {
            get; set;
        }
        private int ave
        {
            get
            {
                return (kor + math + eng) / 3;
            }
        }
    }
}
